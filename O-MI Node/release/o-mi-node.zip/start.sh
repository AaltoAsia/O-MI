#!/bin/sh
java -jar -Dconfig.file=application.conf o-mi-node.jar

